if __name__ == "__main__":
    from faker.cli import execute_from_command_line
    execute_from_command_line()
