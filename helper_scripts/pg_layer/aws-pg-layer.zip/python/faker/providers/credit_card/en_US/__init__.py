from .. import Provider as CreditCardProvider


class Provider(CreditCardProvider):
    pass
