from ..en_PH import Provider as EnPhPhoneNumberProvider


class Provider(EnPhPhoneNumberProvider):
    """No difference from Phone Number Provider for en_PH locale"""
    pass
